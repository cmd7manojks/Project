﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingDal
{ 
    public interface IDataComponent
    {
        void RegisterAdmin(AdminTable admin);
        int LoginAdmin(string emailid, string password);
        void EditAdmin(AdminTable admin);
        List<AdminTable> GetAllAdmins();
        void DeleteAdmin(int id);
        AdminTable GetAdmin(int id);

        void RegisterUser(UserTable user);
        // bool CheckForUniqueEmail(string email);
        int LoginUser(string emailid, string password);
        void EditUser(UserTable user);
        List<UserTable> GetAllUsers();
        void DeleteUser(int id);
        UserTable GetUser(int id);

        void AddNewCategory(CategoryTable category);
        List<CategoryTable> GetAllCategorys();

        void AddProduct(ProductTable product);
        void UpdateProduct(ProductTable product);
        List<ProductTable> GetAllProducts();
        void DeleteProduct(int id);
        ProductTable GetProduct(int id);

        bool AddOrder(OrderTable order);
        List<OrderTable> GetAllOrders();
        void DeleteOrder(int id);
    }

    public class DataComponent : IDataComponent
    {
        static ShopAppEntities shop = new ShopAppEntities();
       
        public void AddNewCategory(CategoryTable category)
        {
            shop.CategoryTables.Add(category);
            shop.SaveChanges();
        }

        public bool AddOrder(OrderTable order)
        {
            try
            {
                shop.OrderTables.Add(order);
                shop.SaveChanges();
                return true;
            }
            catch (Exception )
            {

                return false;
            }
        }

        public void AddProduct(ProductTable product)
        {
            shop.ProductTables.Add(product);
            shop.SaveChanges();
        }

        public void DeleteAdmin(int id)
        {
            try
            {

                var selected = shop.AdminTables.Single((a) => a.AdminId == id);
                if (selected == null) throw new Exception("Admin not found to delete");
                shop.AdminTables.Remove(selected);
                shop.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void DeleteOrder(int id)
        {
            try
            {

                var selected = shop.OrderTables.Single((a) => a.OrderNo == id);
                if (selected == null) throw new Exception("Order not found to delete");
                shop.OrderTables.Remove(selected);
                shop.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /* public bool CheckForUniqueEmail(string email)
         {
             var selected = shop.UserTables.FirstOrDefault((u) => u.EmailId == email);
             return selected == null;
         }*/

        public void DeleteProduct(int id)
        {
            try
            {
               
                var selected = shop.ProductTables.Single((a) => a.ProductId == id);
                if (selected == null) throw new Exception("Product not found to delete");
                shop.ProductTables.Remove(selected);
                shop.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void DeleteUser(int id)
        {
            try
            {

                var selected = shop.UserTables.Single((a) => a.UserId == id);
                if (selected == null)/* throw*/ new Exception("User not found to delete");
                shop.UserTables.Remove(selected);
                shop.SaveChanges();
            }
            catch(Exception ex)
            {
                 new Exception(ex.Message);
            }
        }

        public void EditAdmin(AdminTable admin)
        {
            var selected = shop.AdminTables.FirstOrDefault((e) => e.AdminId == admin.AdminId);
            if (selected == null) throw new Exception("Admin not found to Edit");
            selected.AdminName = admin.AdminName;
            selected.MobileNumber = admin.MobileNumber;
            selected.EmailId = admin.EmailId;
            selected.Password = admin.Password;           
            shop.SaveChanges();
        }

        public void EditUser(UserTable user)
        {
            var selected = shop.UserTables.FirstOrDefault((e) => e.UserId == user.UserId);
            if (selected == null) throw new Exception("User not found to Edit");
            selected.UserName = user.UserName;
            selected.MobileNumber = user.MobileNumber;
            selected.EmailId = user.EmailId;
            selected.Password = user.Password;
            shop.SaveChanges();
        }

        public AdminTable GetAdmin(int id)
        {
            var selected = shop.AdminTables.FirstOrDefault((a) => a.AdminId == id);
            if (selected == null) throw new Exception("Admin not Found");
            return selected;
        }

        public List<AdminTable> GetAllAdmins()
        {
            return new ShopAppEntities().AdminTables.ToList();
        }

        public List<CategoryTable> GetAllCategorys()
        {
            return new ShopAppEntities().CategoryTables.ToList();
        }

        public List<OrderTable> GetAllOrders()
        {
            return new ShopAppEntities().OrderTables.ToList();
        }

        public List<ProductTable> GetAllProducts()
        {
            return new ShopAppEntities().ProductTables.ToList();
        }

        public List<UserTable> GetAllUsers()
        {
            return new ShopAppEntities().UserTables.ToList();
        }

        public ProductTable GetProduct(int id)
        {
            var selected = shop.ProductTables.FirstOrDefault((p) => p.ProductId == id);
            if (selected == null) throw new Exception("Product not Found");
            return selected;

        }

        public UserTable GetUser(int id)
        {
            var selected = shop.UserTables.FirstOrDefault((u) => u.UserId == id);
            if (selected == null) throw new Exception("User not Found");
            return selected;
        }

        public int LoginAdmin(string emailid, string password)
        {
            var selected = shop.AdminTables.FirstOrDefault((u) => ((u.EmailId == emailid) && (u.Password == password)));
            if (selected == null)
            {
                return 0;
            }
            else
            {
                return selected.AdminId;
            }
            // /*throw*/ new Exception("Login failed for the admin");
            //return false;
            //return selected;
        }

        public int LoginUser(string emailid, string password)
        {
            var selected = shop.UserTables.FirstOrDefault((u) => ((u.EmailId == emailid) && (u.Password == password)));
            if (selected != null) //throw new Exception("Login failed for the user");   //return false;
                return selected.UserId;
            else
            {
                return 0;
            }
        }
        public void RegisterAdmin(AdminTable admin)
        {            
            shop.AdminTables.Add(admin);
            shop.SaveChanges();
        }

        public void RegisterUser(UserTable user)
        {
            shop.UserTables.Add(user);
            shop.SaveChanges();
        }

        public void UpdateProduct(ProductTable product)
        {
            var selected = shop.ProductTables.FirstOrDefault((e) => e.ProductId == product.ProductId);
            if (selected == null) throw new Exception("Product not found to update");
            selected.ProductName = product.ProductName;
            selected.Price = product.Price;
            selected.AvailableItems = product.AvailableItems;
            selected.CatId = product.CatId;
            selected.Description = product.Description;
            shop.SaveChanges();
        }
    }

    public static class DataFactory
    {
        public static IDataComponent CreateComponent()
        {
            return new DataComponent();
        }

    }
}
