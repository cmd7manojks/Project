﻿using ShoppingApp.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace ShoppingApp.Controllers
{
    public class ProductController : Controller
    {
        //Home
        public ActionResult Home()
        {
            /*
             HttpContext.Session["CurrentUser"] = "Phaniraj";
              //Debug.WriteLine(this.ControllerContext.HttpContext.Session["CurrentUser"]);*/
            Session.Remove("CurrentUser");
            return View();
        }

        //Admin
        [HttpGet]
        public ActionResult Admins()
        {
            if (Session["CurrentUser"] == null)
            {
                return RedirectToAction("Home");
            }
            else
            {
                IEnumerable<Admin> admins = null;

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:50838/api/");
                    //HTTP GET 
                    var responseTask = client.GetAsync("Admin");
                    responseTask.Wait();

                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<IList<Admin>>();
                        readTask.Wait();

                        admins = readTask.Result;
                    }
                    else //web api sent error response 
                    {
                        //log response status here..

                        admins = Enumerable.Empty<Admin>();

                        ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                    }
                }
                return View(admins);
            }
        }
        public ActionResult AdminLogin()
        {
            if (Session["CurrentUser"] != null)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }

        [HttpPost]
        public ActionResult AdminLogin(string EmailId, string Password)
        {

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50838/api/");
                //HTTP GET 
                var responseTask = client.GetAsync("Admin?emailId=" + EmailId + "&password=" + Password);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    
                    var postTask = result.Content.ReadAsAsync<int>();
                    postTask.Wait();
                   // HttpContext.Session["CurrentUser"] = postTask;
                    var rst = postTask.Result;
                    
                    if (rst !=0)
                    {                       
                        HttpContext.Session["CurrentUser"] = rst;
                        // ViewBag.Adminid = rst;
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ModelState.AddModelError(string.Empty, "Login Credentials are incorrect..");
                    }
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }              
            }           

            return View();
        }
       
        public ActionResult AdminReg()
        {
            if (Session["CurrentUser"] == null)
            {
                return RedirectToAction("Home");
            }
            else
            {
                return View();
            }
        }

        [HttpPost]
        public ActionResult AdminReg(Admin admin)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50838/api/Admin");

                //HTTP POST
                var postTask = client.PostAsJsonAsync<Admin>("Admin", admin);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Admins");
                }
            }

            ModelState.AddModelError(string.Empty, "Not Reach the Credentials. Registration Failed....");

            return View(admin);
        }
        [HttpGet]
        public ActionResult EditAdmin(int id)
        {
            if (Session["CurrentUser"] == null)
            {
                return RedirectToAction("Home");
            }
            else
            {
                Admin admin = null;

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:50838/api/");
                    //HTTP GET
                    var responseTask = client.GetAsync("Admin?id=" + id.ToString());
                    responseTask.Wait();

                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<Admin>();
                        readTask.Wait();

                        admin = readTask.Result;
                    }
                }

                return View(admin);
            }
        }

        [HttpPost]
        public ActionResult EditAdmin(Admin admin)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50838/api/Admin");

                //HTTP POST
                var putTask = client.PutAsJsonAsync<Admin>("Admin", admin);
                putTask.Wait();

                var result = putTask.Result;
                if (result.IsSuccessStatusCode)
                {

                    return RedirectToAction("Index");
                }
            }
            return View(admin);
        }

        public ActionResult DeleteAdmin(int id)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50838/api/");

                //HTTP DELETE
                var deleteTask = client.DeleteAsync("Admin/" + id.ToString());
                deleteTask.Wait();

                var result = deleteTask.Result;
                if (result.IsSuccessStatusCode)
                {

                    return RedirectToAction("Admins");
                }
            }

            return RedirectToAction("Admins");
        }

        //logout both admin and user
        public ActionResult LogOut()
        {
            Session.Remove("CurrentUser");
            return RedirectToAction("Home");
        }

        // User
        [HttpGet]
        public ActionResult Users()
        {
            if (Session["CurrentUser"] == null)
            {
                return RedirectToAction("Home");
            }
            else
            {
                IEnumerable<User> users = null;

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:50838/api/");
                    //HTTP GET 
                    var responseTask = client.GetAsync("User");
                    responseTask.Wait();

                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<IList<User>>();
                        readTask.Wait();

                        users = readTask.Result;
                    }
                    else //web api sent error response 
                    {
                        //log response status here..

                        users = Enumerable.Empty<User>();

                        ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                    }
                }
                return View(users);
            }
        }
        public ActionResult UserLogin()
        {
            if (Session["CurrentUser"] != null)
            {
                return RedirectToAction("Products");
            }
            else
            {
                return View();
            }
        }

        [HttpPost]
        public ActionResult UserLogin(string EmailId, string Password)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50838/api/");
                //HTTP GET 
                var responseTask = client.GetAsync("User?emailId=" + EmailId + "&password=" + Password);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var postTask = result.Content.ReadAsAsync<int>();
                    postTask.Wait();
                    var rst = postTask.Result;
                    if (rst != 0)
                    {
                        HttpContext.Session["CurrentUser"] = rst;
                        return RedirectToAction("Products");
                    }
                    else
                    {
                        ModelState.AddModelError(string.Empty, "Login Credentials are incorrect..");
                    }
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }

            return View();
        }
        public ActionResult UserReg()
        {
            if (Session["CurrentUser"] == null)
            {
                return RedirectToAction("Home");
            }
            else
            {
                return View();
            }
        }

        [HttpPost]
        public ActionResult UserReg(User user)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50838/api/User");

                //HTTP POST
                var postTask = client.PostAsJsonAsync<User>("User", user);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("UserLogin");
                }
            }

            ModelState.AddModelError(string.Empty, "Not Reeach the credentials. Registration Failed....");

            return View(user);
        }
        public ActionResult DeleteUser(int id)
        {
            
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50838/api/");

                //HTTP DELETE
                var deleteTask = client.DeleteAsync("User/" + id.ToString());
                deleteTask.Wait();

                var result = deleteTask.Result;
                if (result.IsSuccessStatusCode)
                {

                    return RedirectToAction("Users");
                }
            }

            return RedirectToAction("Users");
        }

        public ActionResult EditUser(int id)
        {
            if (Session["CurrentUser"] == null)
            {
                return RedirectToAction("Home");
            }
            else
            {
                User user = null;

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:50838/api/");
                    //HTTP GET
                    var responseTask = client.GetAsync("User?id=" + id.ToString());
                    responseTask.Wait();

                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<User>();
                        readTask.Wait();

                        user = readTask.Result;
                    }
                }

                return View(user);
            }
        }

        [HttpPost]
        public ActionResult EditUser(User user)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50838/api/User");

                //HTTP POST
                var putTask = client.PutAsJsonAsync<User>("User", user);
                putTask.Wait();

                var result = putTask.Result;
                if (result.IsSuccessStatusCode)
                {

                    return RedirectToAction("Products");
                }
            }
            return View(user);
        }

        // Product for Admin
        public ActionResult Index()
        {
            if (Session["CurrentUser"] == null)
            {
                return RedirectToAction("Home");
            }
            else
            {
                IEnumerable<Product> products = null;

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:50838/api/");
                    //HTTP GET 
                    var responseTask = client.GetAsync("Product");
                    responseTask.Wait();

                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<IList<Product>>();
                        readTask.Wait();

                        products = readTask.Result;
                    }
                    else //web api sent error response 
                    {
                        //log response status here..

                        products = Enumerable.Empty<Product>();

                        ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                    }
                }
                return View(products);
            }
        }

        public ActionResult create()
        {
            if (Session["CurrentUser"] == null)
            {
                return RedirectToAction("Home");
            }
            else
            {
                return View();
            }
        }

        [HttpPost]
        public ActionResult create(Product product)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50838/api/Product");

                //HTTP POST
                var postTask = client.PostAsJsonAsync<Product>("Product", product);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
            }

            ModelState.AddModelError(string.Empty, "FullFill All The Requirements. Registration Failed....");

            return View(product);
        }


        public ActionResult Edit(int id)
        {
            if (Session["CurrentUser"] == null)
            {
                return RedirectToAction("Home");
            }
            else
            {
                Product product = null;

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:50838/api/");
                    //HTTP GET
                    var responseTask = client.GetAsync("Product?id=" + id.ToString());
                    responseTask.Wait();

                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<Product>();
                        readTask.Wait();

                        product = readTask.Result;
                    }
                }

                return View(product);
            }
        }

        [HttpPost]
        public ActionResult Edit(Product product)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50838/api/Product");

                //HTTP POST
                var putTask = client.PutAsJsonAsync<Product>("Product", product);
                putTask.Wait();

                var result = putTask.Result;
                if (result.IsSuccessStatusCode)
                {

                    return RedirectToAction("Index");
                }
            }
            return View(product);
        }

        public ActionResult Delete(int id)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50838/api/");

                //HTTP DELETE
                var deleteTask = client.DeleteAsync("Product/" + id.ToString());
                deleteTask.Wait();

                var result = deleteTask.Result;
                if (result.IsSuccessStatusCode)
                {

                    return RedirectToAction("Index");
                }
            }

            return RedirectToAction("Index");
        }

        //Category
        public ActionResult Category()
        {
            if (Session["CurrentUser"] == null)
            {
                return RedirectToAction("Home");
            }
            else
            {
                IEnumerable<Category> categories = null;

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:50838/api/");
                    //HTTP GET 
                    var responseTask = client.GetAsync("Category");
                    responseTask.Wait();

                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<IList<Category>>();
                        readTask.Wait();

                        categories = readTask.Result;
                    }
                    else //web api sent error response 
                    {
                        //log response status here..

                        categories = Enumerable.Empty<Category>();

                        ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                    }
                }
                return View(categories);
            }
        }
        public ActionResult AddCategory()
        {
            if (Session["CurrentUser"] == null)
            {
                return RedirectToAction("Home");
            }
            else
            {
                return View();
            }
        }

        [HttpPost]
        public ActionResult AddCategory(Category category)
        {
            
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:50838/api/Category");

                    //HTTP POST
                    var postTask = client.PostAsJsonAsync<Category>("Category", category);
                    postTask.Wait();

                    var result = postTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Category");
                    }
                }

            ModelState.AddModelError(string.Empty, "Not Reach the All Requirements. Adding Failed....");

            return View(category);
            
        }

        //Products User
        public ActionResult Products()
        {
            if (Session["CurrentUser"] == null)
            {
                return RedirectToAction("Home");
            }
            else
            {
                IEnumerable<Product> products = null;

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:50838/api/");
                    //HTTP GET 
                    var responseTask = client.GetAsync("Product");
                    responseTask.Wait();

                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<IList<Product>>();
                        readTask.Wait();

                        products = readTask.Result;
                    }
                    else //web api sent error response 
                    {
                        //log response status here..

                        products = Enumerable.Empty<Product>();

                        ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                    }
                }
                return View(products);
            }
        }

        //cart
        public ActionResult Cart()
        {/*
            if (Session["CurrentUser"] == null)
            {
                return RedirectToAction("Home");
            }
            else
            {
                return View();
            }*/
            return View();
        }
        public void AddToCart(int id)
        {
            /* if (Session["CurrentUser"] == null)
             {
                 return RedirectToAction("Home");
             }
             else
             {
                 return View();
             }*/

           // Product product = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50838/api/");
                //HTTP GET
                var responseTask = client.GetAsync("Product?id=" + id.ToString());
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<Product>();
                    //readTask.Wait();
                    HttpContext.Session["CartItems"] = readTask ;
                   // product = readTask.Result;
                }
               
            }
            RedirectToAction("Products");
        }

        //Order
        public ActionResult Orders()
        {
            if (Session["CurrentUser"] == null)
            {
                return RedirectToAction("Home");
            }
            else
            {
                IEnumerable<Order> orders = null;

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:50838/api/");
                    //HTTP GET 
                    var responseTask = client.GetAsync("Order");
                    responseTask.Wait();

                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<IList<Order>>();
                        readTask.Wait();

                        orders = readTask.Result;
                    }
                    else //web api sent error response 
                    {
                        //log response status here..

                        orders = Enumerable.Empty<Order>();

                        ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                    }
                }
                return View(orders);
            }
        }

        public ActionResult AddOrder()
        {
            if (Session["CurrentUser"] == null)
            {
                return RedirectToAction("Home");
            }
            else
            {
                return View();
            }
        }

        [HttpPost]
        public ActionResult AddOrder(Order order)
        {
            if (Session["CurrentUser"] == null)
            {
                return RedirectToAction("Home");
            }
            else
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:50838/api/Order");

                    //HTTP POST
                    var postTask = client.PostAsJsonAsync<Order>("Order", order);
                    postTask.Wait();

                    var result = postTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var post = result.Content.ReadAsAsync<bool>();
                        postTask.Wait();
                        //Response.Redirect("Index");
                        var rst = post.Result;
                        if (rst)
                        {
                            ModelState.AddModelError(string.Empty, "Order Placed thank you");
                            return RedirectToAction("Index");
                        }
                        else
                        {
                            ModelState.AddModelError(string.Empty, "Order Failed");
                        }
                    }
                    /* else
                     {
                         ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                     }*/

                    return View(order);
                }
            }
        }

        public ActionResult DeleteOrder(int id)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50838/api/");

                //HTTP DELETE
                var deleteTask = client.DeleteAsync("Order/" + id.ToString());
                deleteTask.Wait();

                var result = deleteTask.Result;
                if (result.IsSuccessStatusCode)
                {

                    return RedirectToAction("Orders");
                }
            }

            return RedirectToAction("Orders");
        }
    }
}