using MySql.Data.MySqlClient.Memcached;
using ShoppingApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace ShoppingApp
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            RouteConfig.RegisterRoutes(RouteTable.Routes);

            /*Client.BaseAddress = new Uri("http://localhost:50838/api/");
            //HTTP GET 
            var responseTask = new client.GetAsync("Product");
            var com = new ;
            var data = com.AllProducts.OrderBy((p) => p.ProductName).ToList(); ;
            Application["Products"] = data;*/
        }

        protected void Session_OnStart(object sender, EventArgs e)
        {
           /* Session.Add("CurrentAdmin",new List<Admin>());
            Session.Add("CurrentUser",new List<User>());*/
            /*Session.Add("CurrentProduct",new List<Product>());*/
           
        }
    }
}
