﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShoppingApp.Models
{
    public class Admin
    {
        public int AdminId { get; set; }
        public string AdminName { get; set; }
        public long MobileNumber { get; set; }
        public string EmailId { get; set; }
        public string Password { get; set; }

    }
    public class User
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public long MobileNumber { get; set; }
        public string EmailId { get; set; }
        public string Password { get; set; }
    }
    public class Product
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public decimal Price { get; set; }
        public int AvailableItems { get; set; }
        public int CatId { get; set; }
        public string Description { get; set; }
    }
    public class Category
    {
        public int CatId { get; set; }
        public string CatName { get; set; }
    }
    public class Order
    {
        public int OrderNo { get; set; }
        public string Name { get; set; }
        public long MobileNumber { get; set; }
        public string Address { get; set; }
        public decimal Amount { get; set; }
        public int Quantity { get; set; }
        public int UserId { get; set; }
        public int ProductId { get; set; }
        public DateTime Date { get; set; } = DateTime.Now;

    }
}