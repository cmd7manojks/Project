﻿using ShoppingDal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingBal
{
    public interface IShoppingComponent
    {
        void RegisterAdmin(AdminTable admin);
        int LoginAdmin(string emailid, string password);
        void EditAdmin(AdminTable admin);
        List<AdminTable> GetAllAdmins();
        void DeleteAdmin(int id);
        AdminTable GetAdmin(int id);

        void RegisterUser(UserTable user);
        // bool CheckForUniqueEmail(string email);
        int LoginUser(string emailid, string password);
        void EditUser(UserTable user);
        List<UserTable> GetAllUsers();
        void DeleteUser(int id);
        UserTable GetUser(int id);

        void AddNewCategory(CategoryTable category);
        List<CategoryTable> GetAllCategorys();

        void AddProduct(ProductTable product);
        void UpdateProduct(ProductTable product);
        List<ProductTable> GetAllProducts();
        void DeleteProduct(int id);
        ProductTable GetProduct(int id);

        bool AddOrder(OrderTable order);
        List<OrderTable> GetAllOrders();
        void DeleteOrder(int id);

    }
    public class ShoppingComponent : IShoppingComponent
    {
        static IDataComponent component = DataFactory.CreateComponent();
        public void AddNewCategory(CategoryTable category)
        {
            component.AddNewCategory(category);
        }

        public bool AddOrder(OrderTable order)
        {
           return component.AddOrder(order);

        }

        public void AddProduct(ProductTable product)
        {
            component.AddProduct(product);
        }

        public void DeleteAdmin(int id)
        {
            component.DeleteAdmin(id);
        }

        public void DeleteOrder(int id)
        {
            component.DeleteOrder(id);
        }

        public void DeleteProduct(int id)
        {
            component.DeleteProduct(id);
        }

        public void DeleteUser(int id)
        {
            component.DeleteUser(id);
        }

        public void EditAdmin(AdminTable admin)
        {
            component.EditAdmin(admin);
        }

        public void EditUser(UserTable user)
        {
            component.EditUser(user);
        }

        public AdminTable GetAdmin(int id)
        {
            return component.GetAdmin(id);
        }

        public List<AdminTable> GetAllAdmins()
        {
            return component.GetAllAdmins();
        }

        public List<CategoryTable> GetAllCategorys()
        {
            return component.GetAllCategorys();
        }

        public List<OrderTable> GetAllOrders()
        {
            return component.GetAllOrders();
        }

        public List<ProductTable> GetAllProducts()
        {
            return component.GetAllProducts();
        }

        public List<UserTable> GetAllUsers()
        {
            return component.GetAllUsers();
        }

        public ProductTable GetProduct(int id)
        {
            
            return component.GetProduct(id);
        }

        public UserTable GetUser(int id)
        {
            return component.GetUser(id);
        }

        public int LoginAdmin(string emailid, string password)
        {
           return component.LoginAdmin(emailid, password);
        }

        public int LoginUser(string emailid, string password)
        {
            return component.LoginUser(emailid, password);
        }

        public void RegisterAdmin(AdminTable admin)
        {
            component.RegisterAdmin(admin);
        }

        public void RegisterUser(UserTable user)
        {
            component.RegisterUser(user);
        }

        public void UpdateProduct(ProductTable product)
        {
            component.UpdateProduct(product);
        }
    }
     
    public class ShoppingFactory
    {
        public static IShoppingComponent GetComponent()
        {
            return new ShoppingComponent();
        }
    }
}
