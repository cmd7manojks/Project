﻿using ShoppingBal;
using ShoppingDal;
using ShoppingService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ShoppingService.Controllers
{
    public class CategoryController : ApiController
    {
        static IShoppingComponent component = ShoppingFactory.GetComponent();

        /* [Route("api/Category")]*/
        private CategoryTable Convert(Category rec)
        {
            return new CategoryTable
            {
                CatId = rec.CatId,
                CatName = rec.CatName,
            };
        }

        [HttpPost]
        public bool AddCategory(Category category)
        {
            var rec = Convert(category);
            component.AddNewCategory(rec);
            return true;
        }

       // [Route("api/Category")]
        [HttpGet]
        public List<Category> GetCategory()
        {
            var data = component.GetAllCategorys();
            var catList = data.Select((p) => new Category
            {
                CatId = p.CatId,
                CatName = p.CatName
               
            }).ToList();
            return catList;

        }
    }
}
