﻿using ShoppingBal;
using ShoppingDal;
using ShoppingService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ShoppingService.Controllers
{
    public class UserController : ApiController
    {
        static IShoppingComponent component = ShoppingFactory.GetComponent();

        [HttpGet]
        public List<User> GetAdmins()
        {
            var data = component.GetAllUsers();
            var usrList = data.Select((u) => new User
            {
                UserId = u.UserId,
                UserName = u.UserName,
                MobileNumber = u.MobileNumber,
                EmailId = u.EmailId,
                Password = u.Password
            }).ToList();
            return usrList;

        }
        private User Convert(UserTable rec)
        {
            return new User
            {
                UserId = rec.UserId,
                UserName = rec.UserName,
                MobileNumber = rec.MobileNumber,
                EmailId = rec.EmailId,
                Password = rec.Password
            };
        }
        private UserTable Convert(User user)
        {
            var rec = new UserTable
            {
                UserId = user.UserId,
                UserName = user.UserName,
                MobileNumber = user.MobileNumber,
                EmailId = user.EmailId,
                Password = user.Password
            };
            return rec;
        }
        [HttpPost]
        public bool AddUser(User user)
        {
            var rec = Convert(user);
            component.RegisterUser(rec);
            return true;
        }

        [HttpGet]
        public int Find(string emailid, string password)
        {
            var rec = component.LoginUser(emailid, password);
            
            return rec;

        }
        [HttpGet]
        public User GetAdmin(string id)
        {
            var uid = int.Parse(id);
            var rec = component.GetUser(uid);
            var pro = Convert(rec);
            return pro;
        }



        [HttpDelete]
        public bool DeleteUser(string id)
        {
            var usrId = int.Parse(id);
            component.DeleteUser(usrId);
            return true;
        }

        [HttpPut]
        public bool EditUser(User user)
        {
            var rec = Convert(user);
            component.EditUser(rec);
            return true;
        }

    }
}
