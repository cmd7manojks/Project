﻿using ShoppingBal;
using ShoppingDal;
using ShoppingService.Models;
using System;
using System.Collections.Generic;

using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ShoppingService.Controllers
{
    public class OrderController : ApiController
    {
        static IShoppingComponent component = ShoppingFactory.GetComponent();

        [HttpGet]
        public List<Order> GetOrders()
        {
            var data = component.GetAllOrders();
            var OdrList = data.Select((o) => new Order
            {
                OrderNo = o.OrderNo,
                Name = o.Name,
                MobileNumber = o.MobileNumber,
                Address = o.Address,
                Amount = o.Amount,
                Quantity = o.Quantity,
                UserId = o.UserId,
                ProductId = o.ProductId,
                Date = o.Date
            }).ToList();
            return OdrList;

        }
        private OrderTable Convert(Order order)
        {
            var rec = new OrderTable
            {
                OrderNo = order.OrderNo,
                Name = order.Name,
                MobileNumber = order.MobileNumber,
                Address = order.Address,
                Amount = order.Amount,
                Quantity = order.Quantity,
                UserId = order.UserId,
                ProductId = order.ProductId,
                Date = order.Date

            };
            return rec;
        }
        [HttpPost]
        public bool AddOrder(Order order)
        {
            var rec = Convert(order);
           return component.AddOrder(rec);
            
        }

        [HttpDelete]
        public bool DeleteOrder(string id)
        {
            var odrId = int.Parse(id);
            component.DeleteOrder(odrId);
            return true;
        }
    }
}
