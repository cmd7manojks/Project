﻿using ShoppingBal;
using ShoppingDal;
using ShoppingService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ShoppingService.Controllers
{
    public class ProductController : ApiController
    {
        static IShoppingComponent component = ShoppingFactory.GetComponent();

       // [Route("api/Products")]
        [HttpGet]
        public List<Product> GetProducts()
        {
            var data = component.GetAllProducts();
            var proList = data.Select((p) => new Product
            {
                ProductId = p.ProductId,
                ProductName = p.ProductName,
                Price = p.Price,
                AvailableItems = p.AvailableItems,
                CatId = p.CatId,
                Description = p.Description
            }).ToList();
            return proList;

        }

        private Product Convert(ProductTable rec)
        {
            return new Product
            {
                ProductId = rec.ProductId,
                ProductName = rec.ProductName,
                Price = rec.Price,
                AvailableItems = rec.AvailableItems,
                CatId = rec.CatId,
                Description = rec.Description
            };
        }
        private ProductTable Convert(Product pro)
        {
            var rec = new ProductTable
            {
                ProductId = pro.ProductId,
                ProductName = pro.ProductName,
                Price = pro.Price,
                AvailableItems = pro.AvailableItems,
                CatId = pro.CatId,
                Description = pro.Description
            };
            return rec;
        }

        [HttpGet]
        public Product Find(string id)
        {
            var pid = int.Parse(id);
            var rec = component.GetProduct(pid);
            var pro = Convert(rec);
            return pro;

        }

        [HttpPost]
        public bool AddProduct(Product pro)
        {
            var rec = Convert(pro);
            component.AddProduct(rec);
            return true;
        }

        [HttpDelete]
        public bool DeleteProduct(string id)
        {
            var proId = int.Parse(id);
            component.DeleteProduct(proId);
            return true;
        }

        [HttpPut]
        public bool UpdateProduct(Product pro)
        {
            var rec = Convert(pro);
            component.UpdateProduct(rec);
            return true;
        }

       
    }
}
