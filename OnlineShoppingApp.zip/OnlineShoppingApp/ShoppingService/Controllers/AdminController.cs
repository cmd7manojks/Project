﻿using ShoppingBal;
using ShoppingDal;
using ShoppingService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ShoppingService.Controllers
{
    public class AdminController : ApiController
    {
        static IShoppingComponent component = ShoppingFactory.GetComponent();
        [HttpGet]
        public List<Admin> GetAdmins()
        {
            var data = component.GetAllAdmins();
            var adnList = data.Select((a) => new Admin
            {
                AdminId = a.AdminId,
                AdminName = a.AdminName,
                MobileNumber = a.MobileNumber,
                EmailId = a.EmailId,
                Password = a.Password
            }).ToList();
            return adnList;

        }
        private Admin Convert(AdminTable rec)
        {
            return new Admin
            {
                AdminId = rec.AdminId,
                AdminName = rec.AdminName,
                MobileNumber = rec.MobileNumber,
                EmailId = rec.EmailId,
                Password = rec.Password
            };
        }
        private AdminTable Convert(Admin admin)
        {
            var rec = new AdminTable
            {
                AdminId = admin.AdminId,
                AdminName = admin.AdminName,
                MobileNumber = admin.MobileNumber,
                EmailId = admin.EmailId,
                Password = admin.Password
            };
            return rec;
        }
        [HttpPost]
        public bool AddAdmin(Admin admin)
        {
            var rec = Convert(admin);
            component.RegisterAdmin(rec);
            return true;
        }

        [HttpGet]
        public int Find(string emailId, string password)
        {
            var rec = component.LoginAdmin(emailId, password);
            //if (rec != null)
            //{
            //    return true;
            //}
            //else
                return rec;
            /*  var pro = Convert(rec);
              return pro;
               //return rec;*/

        }
        [HttpGet]
        public Admin GetAdmin(string id)
        {
           var aid = int.Parse(id);
            var rec = component.GetAdmin(aid);
            var pro = Convert(rec);
            return pro;
           

        }

        [HttpDelete]
        public bool DeleteAdmin(string id)
        {
            var adnId = int.Parse(id);
            component.DeleteAdmin(adnId);
            return true;
        }

        [HttpPut]
        public bool EditAdmin(Admin admin)
        {
            var rec = Convert(admin);
            component.EditAdmin(rec);
            return true;
        }

    }
}
